module.exports = (sequelize, DataTypes) => {
  const AlunoCurso = sequelize.define('AlunoCurso', {
    alunoId: {
      type: DataTypes.INTEGER,
      references: { model: 'Alunos', key: 'id' }
    },
    cursoId: {
      type: DataTypes.INTEGER,
      references: { model: 'Cursos', key: 'id' }
    }
  });

  return AlunoCurso;
};