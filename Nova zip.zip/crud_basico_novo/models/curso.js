module.exports = (sequelize, DataTypes) => {
  const Curso = sequelize.define('Curso', {
    nome: DataTypes.STRING,
    descricao: DataTypes.STRING,
  });

  Curso.associate = models => {
    Curso.belongsToMany(models.Aluno, { through: 'AlunoCurso' });
    Curso.hasMany(models.Turma, { foreignKey: 'cursoId' });
  };

  return Curso;
};