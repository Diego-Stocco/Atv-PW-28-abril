module.exports = (sequelize, DataTypes) => {
  const Turma = sequelize.define('Turma', {
    nome: DataTypes.STRING,
    cursoId: {
      type: DataTypes.INTEGER,
      references: { model: 'Cursos', key: 'id' }
    }
  });

  Turma.associate = models => {
    Turma.belongsTo(models.Curso, { foreignKey: 'cursoId' });
  };

  return Turma;
};