const express = require('express');
const router = express.Router();
const { Aluno } = require('../models');

router.get('/', async (req, res) => {
  const alunos = await Aluno.findAll();
  res.json(alunos);
});

router.post('/', async (req, res) => {
  const aluno = await Aluno.create(req.body);
  res.json(aluno);
});

// Adiciona um curso a um aluno
router.post('/:id/cursos', async (req, res) => {
  const aluno = await Aluno.findByPk(req.params.id);
  await aluno.addCurso(req.body.cursoId);
  res.json({ msg: 'Curso adicionado ao aluno' });
});

module.exports = router;