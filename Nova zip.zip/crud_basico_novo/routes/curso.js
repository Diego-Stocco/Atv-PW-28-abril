const express = require('express');
const router = express.Router();
const { Curso } = require('../models');

router.get('/', async (req, res) => {
  const cursos = await Curso.findAll();
  res.json(cursos);
});

router.post('/', async (req, res) => {
  const curso = await Curso.create(req.body);
  res.json(curso);
});

module.exports = router;