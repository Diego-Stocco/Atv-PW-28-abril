const express = require('express');
const router = express.Router();
const { Turma } = require('../models');

router.get('/', async (req, res) => {
  const turmas = await Turma.findAll();
  res.json(turmas);
});

router.post('/', async (req, res) => {
  const turma = await Turma.create(req.body);
  res.json(turma);
});

module.exports = router;